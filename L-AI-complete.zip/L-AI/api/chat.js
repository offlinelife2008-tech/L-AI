export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const apiKey = process.env.OPENROUTER_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: "OPENROUTER_API_KEY is not configured." });
  }

  try {
    const { messages, model, imageData, fileText } = req.body || {};

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: "Messages are required." });
    }

    const safeMessages = messages.slice(-20).map(m => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: typeof m.content === "string" ? m.content.slice(0, 12000) : ""
    }));

    // Optional image support: the frontend sends a data URL.
    // Use a vision-capable model in OPENROUTER_MODEL if you want image understanding.
    if (imageData) {
      const lastUser = [...safeMessages].reverse().findIndex(m => m.role === "user");
      const idx = lastUser >= 0 ? safeMessages.length - 1 - lastUser : -1;
      if (idx >= 0) {
        safeMessages[idx].content = [
          { type: "text", text: safeMessages[idx].content || "Analyze this image." },
          { type: "image_url", image_url: { url: imageData } }
        ];
      }
    }

    if (fileText) {
      const lastUser = [...safeMessages].reverse().findIndex(m => m.role === "user");
      const idx = lastUser >= 0 ? safeMessages.length - 1 - lastUser : -1;
      if (idx >= 0) {
        const extra = String(fileText).slice(0, 30000);
        const current = safeMessages[idx].content;
        safeMessages[idx].content = Array.isArray(current)
          ? [...current, { type: "text", text: `\n\nFile content:\n${extra}` }]
          : `${current}\n\nFile content:\n${extra}`;
      }
    }

    const payload = {
      model: model || process.env.OPENROUTER_MODEL || "openai/gpt-5-mini",
      messages: [
        {
          role: "system",
          content: "You are L AI, a helpful, accurate, friendly AI assistant. Give clear, useful answers. If the user asks in Bangla, answer naturally in Bangla. Do not claim you can do actions you cannot do."
        },
        ...safeMessages
      ],
      temperature: 0.7
    };

    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "HTTP-Referer": process.env.SITE_URL || "https://example.com",
        "X-OpenRouter-Title": process.env.SITE_NAME || "L AI"
      },
      body: JSON.stringify(payload)
    });

    const data = await response.json();

    if (!response.ok) {
      return res.status(response.status).json({
        error: data?.error?.message || "OpenRouter request failed."
      });
    }

    return res.status(200).json({
      answer: data?.choices?.[0]?.message?.content || "No answer returned.",
      model: data?.model || payload.model
    });
  } catch (error) {
    return res.status(500).json({ error: "Server error. Please try again." });
  }
}
