# L AI

A premium, responsive AI chat website powered by OpenRouter and designed for Vercel.

## Features

- Premium animated gradient UI
- L AI chat interface
- OpenRouter server-side API integration
- Photo upload (data URL sent to a vision-capable OpenRouter model)
- TXT/MD/CSV/JSON/HTML text-file upload
- Local conversation history
- Adsterra placeholder
- Google Sign-In placeholder
- Mobile responsive

## 1. Security first

The OpenRouter key that was previously pasted into chat should be revoked. Create a new key and NEVER commit it to GitHub or place it in frontend JavaScript.

Copy `.env.example` conceptually into your Vercel Environment Variables:

OPENROUTER_API_KEY=your_new_key
OPENROUTER_MODEL=your_model_slug
SITE_URL=https://your-deployment.vercel.app
SITE_NAME=L AI

Vercel environment variables are designed for secrets and are available to Functions at runtime.

## 2. Deploy on Vercel

1. Create a GitHub repository.
2. Upload all files in this folder.
3. Import the repository into Vercel.
4. In Vercel: Project -> Settings -> Environment Variables.
5. Add `OPENROUTER_API_KEY` with your NEW key.
6. Add `OPENROUTER_MODEL` with a model that supports your desired capabilities.
7. Redeploy.

## 3. Adsterra

The page has an `Adsterra` placeholder near the composer. After Adsterra approves your site and provides an ad snippet, replace the placeholder in `public/index.html` with their official code.

Do not place an API secret in an ad snippet.

## 4. Google login

The visible button is only a placeholder. For production authentication, connect Firebase Authentication, Auth.js, Supabase Auth, or another OAuth provider. Do not put a Google client secret in browser code.

## 5. File limitations

This starter directly extracts text from TXT/MD/CSV/JSON/HTML. PDF/DOC/DOCX are currently identified but not parsed in the browser. Add a server-side parser or document extraction service for those formats before production.

## 6. Local development

Install Vercel CLI and run:

npm install
vercel dev

Then open the local URL shown by Vercel.

## OpenRouter

The backend uses:
https://openrouter.ai/api/v1/chat/completions

The API key is sent as a Bearer token from the server, not the browser.
